import goa from '../../Assets/ImagesSlider/goa.jpg'
import kerala from '../../Assets/ImagesSlider/kerala.jpg';
import kulu from '../../Assets/ImagesSlider/kulu.jpg';
import ladakh from '../../Assets/ImagesSlider/ladakh.jpg';
import mysore from '../../Assets/ImagesSlider/mysore.jpg';

//myslider\src\Assets\\goa.jpg
export const SliderData = [
    {
      image:
      kulu
    
    },
    {
      image:
       mysore
    },
    {
      image:
       ladakh
    },
    {
      image:
       kerala
    },
    {
      image:
       goa
    }
   
  ];